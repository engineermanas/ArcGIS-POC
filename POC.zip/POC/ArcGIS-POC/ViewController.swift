//
//  ViewController.swift
//  ArcGIS-POC
//
//  Created by Manasa Parida on 8/9/18.
//  Copyright © 2018 Manasa Parida. All rights reserved.
//

import UIKit
import ArcGIS

class ViewController: UIViewController {
    
    @IBOutlet weak var mapView: AGSMapView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let map = AGSMap(basemap: AGSBasemap.imageryWithLabelsVector())
        //let map = AGSMap(basemapType: .navigationVector, latitude: 34.05293, longitude: -118.24368, levelOfDetail: 9)
        //let map = AGSMap(url: URL(string: "https://www.arcgis.com/home/webmap/viewer.html?webmap=b834a68d7a484c5fb473d4ba90d35e71")!)
        mapView.map = map
        setupLocationDisplay()
    }
    
    func setupLocationDisplay() {
        mapView.locationDisplay.autoPanMode = AGSLocationDisplayAutoPanMode.compassNavigation
        mapView.locationDisplay.start { [weak self] (error:Error?) -> Void in
            if let error = error {
                self?.showAlert(withStatus: error.localizedDescription)
            }
        }
    }
    
    func showAlert(withStatus: String) {
        let alertController = UIAlertController(title: "Alert", message:
            withStatus, preferredStyle: UIAlertControllerStyle.alert)
        alertController.addAction(UIAlertAction(title: "Dismiss", style: UIAlertActionStyle.default,handler: nil))
        present(alertController, animated: true, completion: nil)
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
}
